package com.parth.applock.activities

import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.view.WindowManager
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.parth.applock.R
import com.parth.applock.databinding.ActivityLockScreenBinding
import com.parth.applock.utils.CooldownManager
import com.parth.applock.utils.EncryptedPrefs

class LockScreenActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLockScreenBinding
    private var currentPin = ""
    private var targetPackage = ""
    private var lockoutTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen, prevent screenshots
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SECURE  // Block screenshots
        )

        binding = ActivityLockScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        targetPackage = intent.getStringExtra("package_name") ?: ""

        setupNumpad()
        checkLockout()
    }

    private fun setupNumpad() {
        val numButtons = listOf(
            binding.btn0, binding.btn1, binding.btn2, binding.btn3,
            binding.btn4, binding.btn5, binding.btn6, binding.btn7,
            binding.btn8, binding.btn9
        )

        numButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                if (!CooldownManager.isLockedOut()) onDigit(index.toString())
            }
        }

        binding.btnBackspace.setOnClickListener { onBackspace() }
    }

    private fun onDigit(digit: String) {
        if (currentPin.length >= 4) return
        currentPin += digit
        updateDots(currentPin.length)

        if (currentPin.length == 4) {
            validatePin()
        }
    }

    private fun onBackspace() {
        if (currentPin.isNotEmpty()) {
            currentPin = currentPin.dropLast(1)
            updateDots(currentPin.length)
        }
    }

    private fun validatePin() {
        if (EncryptedPrefs.verifyPin(this, currentPin)) {
            // Correct PIN
            onPinCorrect()
        } else {
            // Wrong PIN
            onPinWrong()
        }
    }

    private fun onPinCorrect() {
        CooldownManager.resetAttempts()
        CooldownManager.setUnlocked(targetPackage)
        binding.tvError.visibility = View.GONE
        finish()
    }

    private fun onPinWrong() {
        currentPin = ""
        updateDots(0)
        val attempts = CooldownManager.recordFailedAttempt()

        if (CooldownManager.isLockedOut()) {
            startLockoutTimer()
        } else {
            val remaining = com.parth.applock.utils.Constants.MAX_PIN_ATTEMPTS - attempts
            binding.tvError.text = "Galat PIN! $remaining koshish baaki"
            binding.tvError.visibility = View.VISIBLE
            shakeError()
        }
    }

    private fun startLockoutTimer() {
        binding.numpadLayout.visibility = View.GONE
        binding.lockoutLayout.visibility = View.VISIBLE

        lockoutTimer?.cancel()
        lockoutTimer = object : CountDownTimer(
            com.parth.applock.utils.Constants.LOCKOUT_DURATION_MS, 1000
        ) {
            override fun onTick(millisUntilFinished: Long) {
                val secs = millisUntilFinished / 1000
                binding.tvLockoutTimer.text = "$secs second baad try karein"
            }
            override fun onFinish() {
                binding.numpadLayout.visibility = View.VISIBLE
                binding.lockoutLayout.visibility = View.GONE
                binding.tvError.visibility = View.GONE
            }
        }.start()
    }

    private fun checkLockout() {
        if (CooldownManager.isLockedOut()) {
            startLockoutTimer()
        }
    }

    private fun updateDots(count: Int) {
        val dots = listOf(binding.dot1, binding.dot2, binding.dot3, binding.dot4)
        dots.forEachIndexed { index, dot ->
            dot.isSelected = index < count
            if (index < count) {
                dot.animate().scaleX(1.2f).scaleY(1.2f).setDuration(80).withEndAction {
                    dot.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                }.start()
            }
        }
    }

    private fun shakeError() {
        val shake = AnimationUtils.loadAnimation(this, R.anim.shake)
        binding.pinDotsLayout.startAnimation(shake)
    }

    override fun onBackPressed() {
        // Do NOT allow back press - user must enter PIN
        // Move to home screen instead
        val home = android.content.Intent(android.content.Intent.ACTION_MAIN)
        home.addCategory(android.content.Intent.CATEGORY_HOME)
        home.flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(home)
    }

    override fun onDestroy() {
        super.onDestroy()
        lockoutTimer?.cancel()
    }
}
