package com.parth.applock.utils

import android.content.Context

object AppPrefs {

    private fun prefs(context: Context) =
        context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    fun isFirstLaunch(context: Context): Boolean =
        prefs(context).getBoolean(Constants.KEY_FIRST_LAUNCH, true)

    fun setFirstLaunchDone(context: Context) =
        prefs(context).edit().putBoolean(Constants.KEY_FIRST_LAUNCH, false).apply()

    fun isLockEnabled(context: Context): Boolean =
        prefs(context).getBoolean(Constants.KEY_LOCK_ENABLED, true)

    fun setLockEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(Constants.KEY_LOCK_ENABLED, enabled).apply()

    fun getAutoLockDelay(context: Context): Int =
        prefs(context).getInt(Constants.KEY_AUTO_LOCK_DELAY, 0) // 0 = instant

    fun setAutoLockDelay(context: Context, seconds: Int) =
        prefs(context).edit().putInt(Constants.KEY_AUTO_LOCK_DELAY, seconds).apply()

    // Locked apps stored as comma-separated package names
    fun getLockedApps(context: Context): MutableSet<String> {
        val raw = prefs(context).getStringSet("locked_apps", mutableSetOf()) ?: mutableSetOf()
        return raw.toMutableSet()
    }

    fun saveLockedApps(context: Context, apps: Set<String>) {
        prefs(context).edit().putStringSet("locked_apps", apps).apply()
    }

    fun isAppLocked(context: Context, packageName: String): Boolean {
        return getLockedApps(context).contains(packageName)
    }

    fun lockApp(context: Context, packageName: String) {
        val apps = getLockedApps(context)
        apps.add(packageName)
        saveLockedApps(context, apps)
    }

    fun unlockApp(context: Context, packageName: String) {
        val apps = getLockedApps(context)
        apps.remove(packageName)
        saveLockedApps(context, apps)
    }
}
