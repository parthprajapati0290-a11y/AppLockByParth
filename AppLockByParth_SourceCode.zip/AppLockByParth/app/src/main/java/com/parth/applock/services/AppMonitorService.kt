package com.parth.applock.services

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.parth.applock.R
import com.parth.applock.activities.LockScreenActivity
import com.parth.applock.activities.MainActivity
import com.parth.applock.utils.AppPrefs
import com.parth.applock.utils.Constants
import com.parth.applock.utils.CooldownManager

class AppMonitorService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastTopApp = ""

    private val monitorRunnable = object : Runnable {
        override fun run() {
            try {
                if (AppPrefs.isLockEnabled(applicationContext)) {
                    checkForegroundApp()
                }
            } catch (e: Exception) {
                // Never crash the service
            }
            handler.postDelayed(this, Constants.POLL_INTERVAL_MS)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(Constants.NOTIFICATION_ID, buildNotification())
        handler.post(monitorRunnable)
        return START_STICKY  // Auto-restart if killed
    }

    private fun checkForegroundApp() {
        val topApp = getTopApp() ?: return

        // Skip if same app (no change)
        if (topApp == lastTopApp) return
        lastTopApp = topApp

        // Skip our own app
        if (topApp == packageName) return

        // Check if this app is locked
        if (AppPrefs.isAppLocked(applicationContext, topApp)) {
            // Check cooldown - don't re-lock if user just unlocked
            if (!CooldownManager.isUnlocked(topApp)) {
                showLockScreen(topApp)
            }
        }
    }

    private fun getTopApp(): String? {
        return try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val time = System.currentTimeMillis()
            val stats = usm.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                time - 1000 * 10,  // Last 10 seconds
                time
            )

            stats?.maxByOrNull { it.lastTimeUsed }?.packageName
        } catch (e: Exception) {
            null
        }
    }

    private fun showLockScreen(packageName: String) {
        val intent = Intent(this, LockScreenActivity::class.java).apply {
            putExtra("package_name", packageName)
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_CLEAR_TOP
            )
        }
        startActivity(intent)
    }

    private fun buildNotification(): Notification {
        val lockedCount = AppPrefs.getLockedApps(this).size

        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("🔒 AppLock by Parth")
            .setContentText("$lockedCount apps protected • Tap to manage")
            .setSmallIcon(R.drawable.ic_lock_closed)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSilent(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(monitorRunnable)
    }
}
