package com.parth.applock.activities

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.parth.applock.databinding.ActivityPermissionsBinding
import com.parth.applock.utils.PermissionUtils

class PermissionsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPermissionsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupButtons()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()

        // If both permissions granted, auto-proceed
        if (PermissionUtils.allPermissionsGranted(this)) {
            binding.btnContinue.visibility = View.VISIBLE
        }
    }

    private fun setupButtons() {
        binding.btnUsageAccess.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        binding.btnOverlay.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        binding.btnContinue.setOnClickListener {
            if (PermissionUtils.allPermissionsGranted(this)) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                updatePermissionStatus()
            }
        }
    }

    private fun updatePermissionStatus() {
        val hasUsage = PermissionUtils.hasUsageAccess(this)
        val hasOverlay = PermissionUtils.hasOverlayPermission(this)

        binding.ivUsageCheck.visibility = if (hasUsage) View.VISIBLE else View.GONE
        binding.ivOverlayCheck.visibility = if (hasOverlay) View.VISIBLE else View.GONE
        binding.btnUsageAccess.isEnabled = !hasUsage
        binding.btnOverlay.isEnabled = !hasOverlay

        if (hasUsage && hasOverlay) {
            binding.btnContinue.visibility = View.VISIBLE
        }
    }
}
