package com.parth.applock.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.parth.applock.utils.CooldownManager

class ScreenReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SCREEN_OFF -> {
                // Clear all unlocked apps when screen turns off
                // This re-locks everything when user returns
                CooldownManager.clearAllOnScreenOff()
            }
            Intent.ACTION_USER_PRESENT -> {
                // Screen unlocked - service continues normally
            }
        }
    }
}
