package com.parth.applock.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.parth.applock.R
import com.parth.applock.databinding.ActivitySetupPinBinding
import com.parth.applock.utils.AppPrefs
import com.parth.applock.utils.EncryptedPrefs

class SetupPinActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySetupPinBinding
    private var firstPin = ""
    private var isConfirming = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySetupPinBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
    }

    private fun setupUI() {
        updateTitle()
        val numButtons = listOf(
            binding.btn0, binding.btn1, binding.btn2, binding.btn3,
            binding.btn4, binding.btn5, binding.btn6, binding.btn7,
            binding.btn8, binding.btn9
        )

        numButtons.forEachIndexed { index, button ->
            button.setOnClickListener { onDigitPressed(index.toString()) }
        }

        binding.btnBackspace.setOnClickListener { onBackspace() }
        binding.btnBackspace.setOnLongClickListener { clearInput(); true }
    }

    private fun onDigitPressed(digit: String) {
        val current = binding.pinDisplay.text.toString()
        if (current.length >= 6) return

        val newPin = current + digit
        binding.pinDisplay.setText(newPin)
        updateDots(newPin.length)

        if (newPin.length == 4) {
            onPinComplete(newPin)
        }
    }

    private fun onBackspace() {
        val current = binding.pinDisplay.text.toString()
        if (current.isNotEmpty()) {
            val newPin = current.dropLast(1)
            binding.pinDisplay.setText(newPin)
            updateDots(newPin.length)
        }
    }

    private fun clearInput() {
        binding.pinDisplay.setText("")
        updateDots(0)
    }

    private fun onPinComplete(pin: String) {
        if (!isConfirming) {
            // First entry - ask to confirm
            firstPin = pin
            isConfirming = true
            clearInput()
            updateTitle()
            showMessage("PIN darj hua! Dobara enter karein")
        } else {
            // Confirming PIN
            if (pin == firstPin) {
                // Match! Save PIN
                EncryptedPrefs.savePin(this, pin)
                AppPrefs.setFirstLaunchDone(this)
                showMessage("PIN set ho gaya! ✓")
                binding.root.postDelayed({
                    startActivity(Intent(this, PermissionsActivity::class.java))
                    finish()
                }, 800)
            } else {
                // Mismatch
                isConfirming = false
                firstPin = ""
                clearInput()
                updateTitle()
                shakeError()
                showMessage("PIN match nahi hua! Dobara try karein")
            }
        }
    }

    private fun updateTitle() {
        if (isConfirming) {
            binding.tvTitle.text = "PIN Confirm Karein"
            binding.tvSubtitle.text = "Dobara wahi 4-digit PIN darj karein"
        } else {
            binding.tvTitle.text = "AppLock PIN Set Karein"
            binding.tvSubtitle.text = "Apna 4-digit PIN banayein"
        }
    }

    private fun updateDots(count: Int) {
        val dots = listOf(binding.dot1, binding.dot2, binding.dot3, binding.dot4)
        dots.forEachIndexed { index, dot ->
            dot.isSelected = index < count
        }
    }

    private fun shakeError() {
        val shake = android.view.animation.AnimationUtils.loadAnimation(this, R.anim.shake)
        binding.pinDotsLayout.startAnimation(shake)
    }

    private fun showMessage(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
