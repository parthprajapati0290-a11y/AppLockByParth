package com.parth.applock.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.parth.applock.adapters.AppListAdapter
import com.parth.applock.databinding.ActivityAppListBinding
import com.parth.applock.models.AppInfo
import com.parth.applock.utils.AppPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppListBinding
    private lateinit var adapter: AppListAdapter
    private var allApps = listOf<AppInfo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Apps Select Karein"

        setupRecyclerView()
        setupSearch()
        loadApps()
    }

    private fun setupRecyclerView() {
        adapter = AppListAdapter { appInfo, isLocked ->
            // Toggle lock state
            if (isLocked) {
                AppPrefs.lockApp(this, appInfo.packageName)
            } else {
                AppPrefs.unlockApp(this, appInfo.packageName)
            }
            updateLockedCountTitle()
        }

        binding.recyclerApps.layoutManager = LinearLayoutManager(this)
        binding.recyclerApps.adapter = adapter
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                filterApps(s.toString())
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun loadApps() {
        binding.progressBar.visibility = android.view.View.VISIBLE

        lifecycleScope.launch {
            val apps = withContext(Dispatchers.IO) {
                getInstalledApps()
            }
            allApps = apps
            adapter.submitList(apps)
            binding.progressBar.visibility = android.view.View.GONE
            updateLockedCountTitle()
        }
    }

    private fun getInstalledApps(): List<AppInfo> {
        val pm = packageManager
        val lockedApps = AppPrefs.getLockedApps(this)

        return pm.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA)
            .filter { appInfo ->
                // Only show apps with launch intent (user-visible apps)
                pm.getLaunchIntentForPackage(appInfo.packageName) != null &&
                appInfo.packageName != packageName // Exclude self
            }
            .map { appInfo ->
                AppInfo(
                    appName = pm.getApplicationLabel(appInfo).toString(),
                    packageName = appInfo.packageName,
                    icon = try { pm.getApplicationIcon(appInfo.packageName) } catch (e: Exception) { null },
                    isLocked = lockedApps.contains(appInfo.packageName)
                )
            }
            .sortedWith(
                compareByDescending<AppInfo> { it.isLocked }.thenBy { it.appName }
            )
    }

    private fun filterApps(query: String) {
        val filtered = if (query.isEmpty()) {
            allApps
        } else {
            allApps.filter { it.appName.contains(query, ignoreCase = true) }
        }
        adapter.submitList(filtered)
    }

    private fun updateLockedCountTitle() {
        val count = AppPrefs.getLockedApps(this).size
        supportActionBar?.subtitle = "$count apps locked"
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
