package com.parth.applock.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.parth.applock.R
import com.parth.applock.utils.AppPrefs
import com.parth.applock.utils.EncryptedPrefs
import com.parth.applock.utils.PermissionUtils

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler(Looper.getMainLooper()).postDelayed({
            navigateToNext()
        }, 1500)
    }

    private fun navigateToNext() {
        val intent = when {
            // First launch - setup PIN
            AppPrefs.isFirstLaunch(this) -> Intent(this, SetupPinActivity::class.java)

            // PIN set but permissions not granted
            !PermissionUtils.allPermissionsGranted(this) ->
                Intent(this, PermissionsActivity::class.java)

            // Everything ready - go home
            else -> Intent(this, MainActivity::class.java)
        }
        startActivity(intent)
        finish()
    }
}
