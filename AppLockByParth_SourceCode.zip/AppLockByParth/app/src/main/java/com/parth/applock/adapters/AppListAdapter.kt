package com.parth.applock.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.parth.applock.databinding.ItemAppBinding
import com.parth.applock.models.AppInfo

class AppListAdapter(
    private val onToggle: (AppInfo, Boolean) -> Unit
) : ListAdapter<AppInfo, AppListAdapter.AppViewHolder>(AppDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val binding = ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AppViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class AppViewHolder(private val binding: ItemAppBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(app: AppInfo) {
            binding.tvAppName.text = app.appName
            binding.tvPackageName.text = app.packageName
            binding.ivAppIcon.setImageDrawable(app.icon)
            binding.switchAppLock.isChecked = app.isLocked

            // Prevent listener firing on rebind
            binding.switchAppLock.setOnCheckedChangeListener(null)
            binding.switchAppLock.isChecked = app.isLocked

            binding.switchAppLock.setOnCheckedChangeListener { _, isChecked ->
                app.isLocked = isChecked
                onToggle(app, isChecked)
            }

            binding.root.setOnClickListener {
                binding.switchAppLock.toggle()
            }
        }
    }

    class AppDiffCallback : DiffUtil.ItemCallback<AppInfo>() {
        override fun areItemsTheSame(oldItem: AppInfo, newItem: AppInfo) =
            oldItem.packageName == newItem.packageName
        override fun areContentsTheSame(oldItem: AppInfo, newItem: AppInfo) =
            oldItem.isLocked == newItem.isLocked
    }
}
