package com.parth.applock.utils

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

object EncryptedPrefs {

    private const val FILE_NAME = "applock_secure_prefs"

    private fun getPrefs(context: Context) = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback to normal prefs if encryption fails (rare)
        context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
    }

    fun savePin(context: Context, pin: String) {
        val hash = hashPin(pin)
        getPrefs(context).edit().putString(Constants.KEY_PIN_HASH, hash).apply()
    }

    fun verifyPin(context: Context, input: String): Boolean {
        val saved = getPrefs(context).getString(Constants.KEY_PIN_HASH, null) ?: return false
        return hashPin(input) == saved
    }

    fun hasPin(context: Context): Boolean {
        return getPrefs(context).getString(Constants.KEY_PIN_HASH, null) != null
    }

    fun clearPin(context: Context) {
        getPrefs(context).edit().remove(Constants.KEY_PIN_HASH).apply()
    }

    private fun hashPin(pin: String): String {
        // SHA-256 hash with app-specific salt
        val salt = "AppLockByParth_2024_Secure"
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest("$salt$pin".toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
