package com.parth.applock.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.parth.applock.databinding.ActivityMainBinding
import com.parth.applock.services.AppMonitorService
import com.parth.applock.utils.AppPrefs
import com.parth.applock.utils.PermissionUtils

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        startMonitorService()
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun setupUI() {
        // Lock ON/OFF switch
        binding.switchLock.setOnCheckedChangeListener { _, isChecked ->
            AppPrefs.setLockEnabled(this, isChecked)
            updateLockStatusUI(isChecked)
            if (isChecked) startMonitorService() else stopMonitorService()
        }

        // App list button
        binding.btnSelectApps.setOnClickListener {
            startActivity(Intent(this, AppListActivity::class.java))
        }

        // Settings button
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        // Permission warning click
        binding.cardPermissionWarning.setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }
    }

    private fun updateUI() {
        val lockEnabled = AppPrefs.isLockEnabled(this)
        val lockedCount = AppPrefs.getLockedApps(this).size
        val permsOk = PermissionUtils.allPermissionsGranted(this)

        binding.switchLock.isChecked = lockEnabled
        updateLockStatusUI(lockEnabled)

        binding.tvLockedCount.text = "$lockedCount Apps Protected"
        binding.tvLockedCountSub.text = if (lockedCount == 0) "Koi app select nahi hai" else "Secure hain"

        // Permission warning card
        binding.cardPermissionWarning.visibility =
            if (!permsOk) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun updateLockStatusUI(enabled: Boolean) {
        if (enabled) {
            binding.tvLockStatus.text = "App Lock Active"
            binding.tvLockStatusSub.text = "Aapke apps secure hain"
            binding.ivLockIcon.setImageResource(com.parth.applock.R.drawable.ic_lock_closed)
            binding.cardLockStatus.setCardBackgroundColor(
                getColor(com.parth.applock.R.color.status_active)
            )
        } else {
            binding.tvLockStatus.text = "App Lock Inactive"
            binding.tvLockStatusSub.text = "Tap karein enable karne ke liye"
            binding.ivLockIcon.setImageResource(com.parth.applock.R.drawable.ic_lock_open)
            binding.cardLockStatus.setCardBackgroundColor(
                getColor(com.parth.applock.R.color.status_inactive)
            )
        }
    }

    private fun startMonitorService() {
        if (PermissionUtils.allPermissionsGranted(this)) {
            val intent = Intent(this, AppMonitorService::class.java)
            startForegroundService(intent)
        }
    }

    private fun stopMonitorService() {
        stopService(Intent(this, AppMonitorService::class.java))
    }
}
