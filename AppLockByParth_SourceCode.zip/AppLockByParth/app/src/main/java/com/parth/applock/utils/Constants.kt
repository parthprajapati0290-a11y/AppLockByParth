package com.parth.applock.utils

object Constants {
    const val NOTIFICATION_CHANNEL_ID = "applock_service_channel"
    const val NOTIFICATION_ID = 1001
    const val PREFS_NAME = "applock_prefs"
    const val KEY_FIRST_LAUNCH = "first_launch"
    const val KEY_PIN_HASH = "pin_hash"
    const val KEY_LOCK_ENABLED = "lock_enabled"
    const val KEY_AUTO_LOCK_DELAY = "auto_lock_delay"
    const val COOLDOWN_MS = 5000L        // 5 seconds after unlock
    const val POLL_INTERVAL_MS = 600L   // Check every 600ms
    const val MAX_PIN_ATTEMPTS = 5
    const val LOCKOUT_DURATION_MS = 30000L // 30 sec lockout
}
