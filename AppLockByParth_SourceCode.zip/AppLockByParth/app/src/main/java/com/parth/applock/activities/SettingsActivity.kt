package com.parth.applock.activities

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.parth.applock.databinding.ActivitySettingsBinding
import com.parth.applock.utils.AppPrefs
import com.parth.applock.utils.CooldownManager
import com.parth.applock.utils.EncryptedPrefs

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Settings"

        setupUI()
    }

    private fun setupUI() {
        // Auto lock delay
        val delays = arrayOf("Instant", "5 Seconds", "10 Seconds", "30 Seconds")
        val delayValues = arrayOf(0, 5, 10, 30)
        val currentDelay = AppPrefs.getAutoLockDelay(this)
        val currentIndex = delayValues.indexOf(currentDelay).takeIf { it >= 0 } ?: 0
        binding.tvAutoLockValue.text = delays[currentIndex]

        binding.layoutAutoLock.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Auto Lock Delay")
                .setSingleChoiceItems(delays, currentIndex) { dialog, which ->
                    AppPrefs.setAutoLockDelay(this, delayValues[which])
                    binding.tvAutoLockValue.text = delays[which]
                    dialog.dismiss()
                }
                .show()
        }

        // Change PIN
        binding.layoutChangePin.setOnClickListener {
            showChangePinDialog()
        }

        // Privacy Policy
        binding.layoutPrivacyPolicy.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://sites.google.com/view/applock-by-parth-privacy")))
        }

        // About
        binding.layoutAbout.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("AppLock by Parth")
                .setMessage("Version 1.0\n\nYe app aapke apps ko surakshit rakhti hai.\n\nDeveloper: Parth\nEmail: support@applockbyparth.com")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun showChangePinDialog() {
        val view = layoutInflater.inflate(com.parth.applock.R.layout.dialog_change_pin, null)
        val etOld = view.findViewById<android.widget.EditText>(com.parth.applock.R.id.etOldPin)
        val etNew = view.findViewById<android.widget.EditText>(com.parth.applock.R.id.etNewPin)
        val etConfirm = view.findViewById<android.widget.EditText>(com.parth.applock.R.id.etConfirmPin)

        AlertDialog.Builder(this)
            .setTitle("PIN Change Karein")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                val old = etOld.text.toString()
                val new = etNew.text.toString()
                val confirm = etConfirm.text.toString()

                when {
                    !EncryptedPrefs.verifyPin(this, old) ->
                        Toast.makeText(this, "Purana PIN galat hai!", Toast.LENGTH_SHORT).show()
                    new.length < 4 ->
                        Toast.makeText(this, "PIN 4 digit ka hona chahiye", Toast.LENGTH_SHORT).show()
                    new != confirm ->
                        Toast.makeText(this, "Naya PIN match nahi hua!", Toast.LENGTH_SHORT).show()
                    else -> {
                        EncryptedPrefs.savePin(this, new)
                        CooldownManager.resetAttempts()
                        Toast.makeText(this, "PIN change ho gaya ✓", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
