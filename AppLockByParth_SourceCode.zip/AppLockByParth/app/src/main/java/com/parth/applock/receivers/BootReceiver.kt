package com.parth.applock.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.parth.applock.services.AppMonitorService
import com.parth.applock.utils.AppPrefs
import com.parth.applock.utils.PermissionUtils

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            // Auto-start service on boot if lock was enabled
            if (AppPrefs.isLockEnabled(context) &&
                PermissionUtils.allPermissionsGranted(context)) {
                val serviceIntent = Intent(context, AppMonitorService::class.java)
                context.startForegroundService(serviceIntent)
            }
        }
    }
}
