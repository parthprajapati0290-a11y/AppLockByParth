package com.parth.applock.utils

object CooldownManager {

    private val unlockedApps = mutableMapOf<String, Long>()
    private var lockoutUntil = 0L
    private var failedAttempts = 0

    fun setUnlocked(packageName: String) {
        unlockedApps[packageName] = System.currentTimeMillis()
    }

    fun isUnlocked(packageName: String): Boolean {
        val unlockTime = unlockedApps[packageName] ?: return false
        val elapsed = System.currentTimeMillis() - unlockTime
        return elapsed < Constants.COOLDOWN_MS
    }

    fun clearUnlock(packageName: String) {
        unlockedApps.remove(packageName)
    }

    fun clearAllOnScreenOff() {
        unlockedApps.clear()
    }

    // Brute force protection
    fun recordFailedAttempt(): Int {
        failedAttempts++
        if (failedAttempts >= Constants.MAX_PIN_ATTEMPTS) {
            lockoutUntil = System.currentTimeMillis() + Constants.LOCKOUT_DURATION_MS
            failedAttempts = 0
        }
        return failedAttempts
    }

    fun isLockedOut(): Boolean = System.currentTimeMillis() < lockoutUntil

    fun getLockoutRemainingSeconds(): Int {
        val remaining = lockoutUntil - System.currentTimeMillis()
        return if (remaining > 0) (remaining / 1000).toInt() else 0
    }

    fun resetAttempts() {
        failedAttempts = 0
        lockoutUntil = 0L
    }

    fun getFailedAttempts() = failedAttempts
}
