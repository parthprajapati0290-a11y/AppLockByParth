# 🔐 AppLock by Parth
### Complete Android App Lock - Play Store Ready Source Code

---

## 📁 Project Structure
```
AppLockByParth/
├── app/src/main/
│   ├── java/com/parth/applock/
│   │   ├── activities/          ← Sabhi screens
│   │   │   ├── SplashActivity.kt
│   │   │   ├── SetupPinActivity.kt
│   │   │   ├── PermissionsActivity.kt
│   │   │   ├── MainActivity.kt
│   │   │   ├── AppListActivity.kt
│   │   │   ├── LockScreenActivity.kt
│   │   │   └── SettingsActivity.kt
│   │   ├── services/
│   │   │   └── AppMonitorService.kt  ← Background brain
│   │   ├── receivers/
│   │   │   ├── BootReceiver.kt
│   │   │   └── ScreenReceiver.kt
│   │   ├── adapters/
│   │   │   └── AppListAdapter.kt
│   │   ├── models/
│   │   │   └── AppInfo.kt
│   │   └── utils/
│   │       ├── Constants.kt
│   │       ├── EncryptedPrefs.kt   ← Secure PIN storage
│   │       ├── AppPrefs.kt
│   │       ├── CooldownManager.kt
│   │       └── PermissionUtils.kt
│   ├── res/                     ← Layouts, drawables, values
│   └── AndroidManifest.xml
├── build.gradle
├── settings.gradle
└── README.md  ← Aap yahan hain
```

---

## 🛠️ STEP 1 — Android Studio Install Karo

1. **Download:** https://developer.android.com/studio
2. Install karo (default settings)
3. JDK 17 automatically aata hai

---

## 📂 STEP 2 — Project Open Karo

1. Android Studio open karo
2. **"Open"** click karo
3. `AppLockByParth` folder select karo
4. Gradle sync hone do (2-3 minutes)

---

## ▶️ STEP 3 — App Run Karo (Testing)

### Emulator pe:
1. `Tools > AVD Manager > Create Device`
2. Pixel 6 + Android 13 select karo
3. Green ▶️ button dabao

### Real Phone pe:
1. Phone mein `Settings > Developer Options > USB Debugging` ON karo
2. USB se connect karo
3. ▶️ dabao → phone pe install ho jaayega

---

## 🔑 STEP 4 — Keystore Banao (Play Store ke liye ZAROOR)

Android Studio mein:
```
Build > Generate Signed Bundle/APK
  → Android App Bundle (.aab) select karo
  → "Create new keystore" click karo
  → Fill karo:
      Keystore path: C:/Users/YourName/applock-key.jks
      Password: [strong password - YAAD RAKHNA!]
      Alias: applock-parth
      Validity: 25 years
  → Next > Release > Finish
```

**⚠️ IMPORTANT:** keystore file aur password kabhi delete mat karna!
Yeh file se hi future updates upload honge.

---

## 📱 STEP 5 — Play Store Pe Upload

### 5.1 Developer Account Banao
- https://play.google.com/console
- $25 one-time fee
- 2-3 din verification

### 5.2 New App Create Karo
```
All Apps > Create App
  App name: AppLock by Parth
  Default language: Hindi (India)
  App or Game: App
  Free or Paid: Free
```

### 5.3 Store Listing Fill Karo
```
Short description (80 chars):
"Apne apps ko PIN se lock karein - Simple, Fast, Secure"

Full description:
AppLock by Parth aapke Android phone ke apps ko surakshit rakhta hai.

✅ Features:
• Koi bhi app lock karein - WhatsApp, Instagram, Gallery sab
• 4-digit PIN protection
• Screenshot block - privacy secure
• Auto re-lock jab screen band ho
• Bahut kam battery use karta hai
• Simple aur fast interface

🔒 Security:
• PIN encrypted store hota hai
• Wrong PIN 5 baar → 30 second lockout
• Koi data upload nahi hota

💯 Bilkul free, koi ads nahi
```

### 5.4 Content Rating
- IARC questionnaire fill karo
- "Everyone" rating milegi

### 5.5 Privacy Policy
- **ZAROOR CHAHIYE** Play Store ke liye!
- Free banao: https://sites.google.com (Google Sites)
- Ya: https://app-privacy-policy-generator.firebaseapp.com
- URL: `https://sites.google.com/view/applock-by-parth-privacy`
- SettingsActivity.kt mein wahi URL daalo

### 5.6 .aab Upload Karo
```
Production > Releases > Create new release
  → Upload .aab file
  → Release notes: "Pehla release - basic app lock features"
  → Review and publish
```

### 5.7 Wait Karo
- Review: 3-7 din
- Approval ke baad live ho jaayega

---

## ⚠️ Play Store Approval Tips

### ✅ Karo:
- Privacy policy add karo (URL SettingsActivity mein hai)
- Sahi description likho
- Screenshots acche lo

### ❌ Mat Karo:
- "Spy" ya "monitor" word use mat karo description mein
- Hidden features mat daalo
- Kisi aur app ka naam mat likho

---

## 📸 Screenshots Kaise Lo

Phone pe app install karo, phir:
- Home screen screenshot
- App list screenshot  
- Lock screen screenshot (doosre phone se lo)
- Settings screenshot

Play Store ko chahiye: 2-8 screenshots (1080x1920 px)

---

## 💰 AdMob Add Karna (Baad Mein)

Jab app approve ho jaye, tab AdMob add karo:

### build.gradle mein add karo:
```gradle
implementation 'com.google.android.gms:play-services-ads:23.0.0'
```

### MainActivity mein:
```kotlin
// onCreate mein:
MobileAds.initialize(this)

// Banner ad:
val adRequest = AdRequest.Builder().build()
binding.adView.loadAd(adRequest)
```

### activity_main.xml mein:
```xml
<com.google.android.gms.ads.AdView
    android:id="@+id/adView"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    ads:adSize="BANNER"
    ads:adUnitId="ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"/>
```

AdMob account: https://admob.google.com

---

## 🆘 Common Errors & Fixes

| Error | Fix |
|-------|-----|
| `Gradle sync failed` | File > Invalidate Caches > Restart |
| `minSdk version error` | build.gradle mein minSdk 23 check karo |
| `Missing resource` | Build > Clean Project phir Rebuild |
| `Manifest merge error` | AndroidManifest.xml check karo |

---

## 📞 Support
Koi problem ho toh: parthdev.applock@gmail.com

**Version:** 1.0  
**Min Android:** 6.0 (API 23)  
**Target Android:** 14 (API 34)
